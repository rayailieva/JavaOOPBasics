package pawInc.centers;

import pawInc.animals.Animal;

import java.util.ArrayList;
import java.util.List;

public class AdoptionCenter extends Center {

    private List<Animal> storedAnimals;

    public AdoptionCenter(int name) {
        super(name);
        this.storedAnimals = new ArrayList<>();
    }

    public List<Animal> getStoredAnimals() {
        return this.storedAnimals;
    }

    private void setStoredAnimals(List<Animal> storedAnimals) {
        this.storedAnimals = storedAnimals;
    }
}
