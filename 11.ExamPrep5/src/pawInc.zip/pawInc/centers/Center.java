package pawInc.centers;

import pawInc.animals.Animal;

import java.util.ArrayList;
import java.util.List;

public abstract class Center {
    private int name;
    private List<Animal> storedAnimals;

    public Center(int name) {
        this.name = name;
        this.storedAnimals = new ArrayList<>();
    }

    public int getName() {
        return this.name;
    }

    private void setName(int name) {
        this.name = name;
    }

    public List<Animal> getStoredAnimals() {
        return this.storedAnimals;
    }

    private void setStoredAnimals(List<Animal> storedAnimals) {
        this.storedAnimals = storedAnimals;
    }
}
