package pawInc.centers;

import pawInc.animals.Animal;

import java.util.ArrayList;
import java.util.List;

public class CleasingCenter extends Center {
    private List<Animal> storedAnimals;

    public CleasingCenter(int name) {
        super(name);
        this.storedAnimals = new ArrayList<>();
    }

    public List<Animal> getStoredAnimals() {
        return this.storedAnimals;
    }

    private void setStoredAnimals(List<Animal> storedAnimals) {
        this.storedAnimals = storedAnimals;
    }
}
