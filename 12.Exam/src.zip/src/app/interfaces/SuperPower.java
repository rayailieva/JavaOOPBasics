package app.interfaces;

public interface SuperPower {

    String getName();

    double getPowerPoints();
}
